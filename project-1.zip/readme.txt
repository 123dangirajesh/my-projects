Movie page created using python version (3.6.0)
A simple movie page which shows movie trailer and can be run easily on any webbrowser


______________About the software_____________


Python has a design philosophy which emphasizes code readability (notably using whitespace indentation to delimit code blocks rather than curly brackets or keywords), and a syntax which allows programmers to express concepts in fewer lines of code than might be used in languages such as C++
  
-----pre-requisites----
1 -Latest version of python has to be installed to run the code (if not than get it from "https://www.python.org/".)
2 -A text editor of python (IDLE python)
3 -Some more library that you need to import in code such as -twilio,much more. 

-----Features-----
1 -It work on Mac , Window.(tested and ran successfully)
2 -Easy to Download ,install and run .
3 -Cross platform software(as shown above)
4 -Shows the process output in the python shell.
5 -it is a free software.



____________About the Movie trailer page_________

1 - I have created a movie trailer page using the python in backend and imported a file for forntend scripting. 
2 - i have created two python files of program code 
          -i) 1st for showing the inforamtion about what my code is about i.e-class file.
          -ii)2nd for the calling all the detalis of "class file" that i have made.
3 - Now i have combined the these two files using the function and objects of the written class.
4 - when you will run these code you will see the movie trailer page will executed in browser.
    and when you will click on the any movie image then you can see the movie trailer. 



-----About Code-----
The code files are written by me in my python editor and i hope that every file i have written are easy to understand .
This code have number of classes and there instances or objects with help of which i have combined the two files of code.
   


 

 



 